import 'package:flutter/cupertino.dart';
import 'package:flutter_animate/flutter_animate.dart';


extension WiEx on Widget{
  Widget myAnimated(){
    return animate(delay: const Duration(milliseconds: 500))
        .fadeIn(delay: const Duration(milliseconds: 100))
        .slide(
        begin: const Offset(.5, 5),
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
        delay: const Duration(milliseconds: 100))
        .animate()
        .shimmer(duration: const Duration(milliseconds: 3500));
  }
  Widget slideAnimatedY({
    bool enable =true,
    double begin =0.2,
  }){
    return enable? animate(
    ).fadeIn(duration: 800.ms)
        .slideY(begin: begin, end: 0,duration: 800.ms ):this;
  }
  Widget slideAnimatedX({
    bool enable =true,
    double begin =0.2,
    double duration =800,
    BuildContext? context,
  }){
    bool isLeft =true;
    if(context!=null) {
      TextDirection direction = Directionality.of(context);
      isLeft = direction ==TextDirection.ltr;
    }

    return enable? animate(
    ).fadeIn(duration: 800.ms)
        .slideX(begin: isLeft?begin:-begin, end: 0,duration: duration.ms ):this;
  }

}
